import { Component } from '@angular/core';
import { ReplaySubject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';
  name="raju";
  getname(){
    return this.name;
  }
  person={
    age:"20",
    game:"cricket"
  };
}
