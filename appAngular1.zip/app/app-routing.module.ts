import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
import { HomeComponent } from './home/home.component';
import { MainComponent } from './main/main.component';
import { MobileComponent } from './mobile/mobile.component';
import { AgrComponent } from './products/agr/agr.component';
import { ProComponent } from './products/pro/pro.component';
import { ProductsComponent } from './products/products.component';
import { QulityComponent } from './qulity/qulity.component';

const routes: Routes = [
  {path:'main',component:MainComponent},
  {path:'home',component:HomeComponent},
  {path:'qulity',component:QulityComponent},
 {path:'products',component:ProductsComponent,children:[
   
   {path:'pro',component:ProComponent}
  ]},
 


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
