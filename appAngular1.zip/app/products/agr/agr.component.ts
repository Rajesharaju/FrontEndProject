import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agr',
  templateUrl: './agr.component.html',
  styleUrls: ['./agr.component.css']
})
export class AgrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
