import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgrComponent } from './agr.component';

describe('AgrComponent', () => {
  let component: AgrComponent;
  let fixture: ComponentFixture<AgrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgrComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
