import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QulityComponent } from './qulity.component';

describe('QulityComponent', () => {
  let component: QulityComponent;
  let fixture: ComponentFixture<QulityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QulityComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QulityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
