import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qulity',
  templateUrl: './qulity.component.html',
  styleUrls: ['./qulity.component.css']
})
export class QulityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
