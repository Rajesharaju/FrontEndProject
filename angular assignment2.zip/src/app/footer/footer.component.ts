import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  template: `<div class=main>
           <h1><strong>Employee Inttersts Survey form</strong></h1>
           <form>
Enter your name:
<input type="text" name="Name" size="20">
<br> <br>
Enter your department:
<input type="text" name="Course" size="15">
<br> <br>
<div class="about">
Tell us a little about ypur self:
<input type="text" name="Course" size="15">
</div>
</form>
<form>
<legend>DO you exercise at home?</legend>
        <input type="radio" name="favorite_pet" value="yes">yes
        <input type="radio" name="favorite_pet" value="no">no
      </form>  
        <div class="check">
        <form >
        How do you like to read about your favorite topic?<br>
  <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
  <label for="vehicle1"> books</label>
  <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
  <label for="vehicle2"> online course</label>
  <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
  <label for="vehicle3"> Pione apps</label>
  <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
  <label for="vehicle3"> magazines</label>

  </form>
  </div>

  <form action="/action_page.php">
  <label for="cars">What genre of movies do you like?:</label>
  <select name="cars" id="comedy">
    <option value="volvo">Volvo</option>
    <option value="saab">Saab</option>
    <option value="opel">Opel</option>
    <option value="audi">Audi</option>
  </select>
  <br><br>
  <div class="submit">
  <input type="submit" value="Submit">
  </div>
</form>
  
  

           </div>
           
  `,
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
name="raj"
}
