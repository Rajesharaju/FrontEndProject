import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  fname:string='';
  lname:string='';
  age:string='';
  terms:boolean=false;
 
  onSubmit(formValue:NgForm){
    console.log(formValue.value)
    console.log(formValue)
  }
  resetForm(formValue:NgForm){
    formValue.reset()
  }
}


  




//   name="raju";
//   disabledbox=true
//   enableInput(){
// this.disabledbox=false
//   }
//   placeholderText: string = "Please enter new value";
//   isExist = false;
//   existPlaceHolderText = "Please add new value"
//   change(){
//     this.isExist=true
//   }
//   day=true;
//   name1="raju";
//   array=[1,2,3];
// names=[
//   {
//     fname:'raj',
//     lastname:'ravi'
//   },
//   {
//     fname:'sanju',
//     lastname:'raj'
//   },
//   {
//     fname:'ram',
//     lastname:'kumar'
//   },
// ]
// number = 'H';

// stylecolor="newfont";
// textColor="gray";
// bgcolo="black";

// datex=Date()
// }



