import { Directive,ElementRef,HostBinding,HostListener,Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {

  constructor(private el:ElementRef,private renderer:Renderer2)  {
    el.nativeElement.style.color="blue";
  }
  ngOnInit(){
    this.renderer.setStyle(this.el.nativeElement,'background-color','pink',);
    this.renderer.setStyle(this.el.nativeElement,'font-size','50px',);
    this.renderer.setStyle(this.el.nativeElement,'font-style','italic',);
 
  }




//    @HostBinding("style.backgroundColor") bgcolor;
// @HostListener('mouseenter') mouseenter(){
//   this.changecolor("red");
//   this,this.bgcolor="gray"
// }
// changecolor(color){
//   this.el.nativeElement.style.color=color;
// }
// @HostListener('mouseout') mouseout(){
//   this.changecolor1("blue");
// }
// changecolor1(color){
//   this.el.nativeElement.style.color=color;
// }



}
