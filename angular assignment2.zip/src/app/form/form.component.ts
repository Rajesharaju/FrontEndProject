// import { Component, OnInit } from '@angular/core';
// import { FormControl, FormGroup } from '@angular/forms';

// @Component({
//   selector: 'app-form',
//   templateUrl: './form.component.html',
//   styleUrls: ['./form.component.css']
// })
// export class FormComponent implements OnInit {
//   myReactiveForm:FormGroup;
//   constructor() { }

//   ngOnInit(): void {
// this.myReactiveForm=new FormGroup({
//   'fname':new FormControl(null),
//   'lname':new FormControl(null),
//   'email':new FormControl(null),
//   'password':new FormControl(null)
// });

//   }
//   onSubmit(){
//     console.log(this.myReactiveForm.value);
//   }

//
 
