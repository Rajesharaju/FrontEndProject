import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { SighnUpComponent } from './sighn-up/sighn-up.component';





@NgModule({
  declarations: [
    LoginComponent,
    SighnUpComponent
  ],
  
  imports: [
    CommonModule
  ],
  exports:[
    LoginComponent,
    SighnUpComponent
    
  ],
  
})
export class UsersModule { }
