import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NeedDataService {

  constructor() { }
  products=['football','cricket','kabbadi']
}
