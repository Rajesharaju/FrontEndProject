package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins="http://localhost:4200/")
@RestController
@RequestMapping("/api")
public class StudentdataController {
	@Autowired
	StudentdataRepository repository;
	@GetMapping("/Getstudents")
	public List<Studentdata> getAllStudents()
	{
		return repository.findAll();
	}
	@PostMapping("/student")
	public void saveStudentdata(@RequestBody Studentdata s)
	{
		repository.save(s);
	}
}
	
	
	
	
	
	
	
	
	
	
	
//	@PostMapping("/deletstudent/{regno}")
//	public void deleteStudentdetails(@PathVariable String regno){
//		repository.delete(regno);
//	}
//	@GetMapping("/getstu/{regno}")
//	public void getStudentDetails(@PathVariable String regno)
//	{
//		repository.get(regno);
//	}
//	
//	@GetMapping("/users/{regno}")  
//	public Optional<Studentdata> retriveUser(@PathVariable String regno)  
//	{  
//	return repository.findone(regno);  
//	}
//	
//	
//	@PostMapping("/updatestudent/{regno}")
//	public void updateStudentdetails(@PathVariable String regno,@RequestBody Studentdata st) {
//		repository.update(st,regno);
//}
//}	
//
