package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Studentdata1Application  {
//	implements CommandLineRunner
	public static void main(String[] args) {
		SpringApplication.run(Studentdata1Application.class, args);
		
		
	}
}
//	}
//@Autowired
//StudentdataRepository repository;
//
//@Override
//public void run(String...args)throws Exception
//{
//	this.repository.save(new Studentdata("ss","d1","s2","s3"));
//	this.repository.save(new Studentdata("ss","ss2","s3","s3"));
//	this.repository.save(new Studentdata("ss","ss3","s1","s4"));
//}
//}
