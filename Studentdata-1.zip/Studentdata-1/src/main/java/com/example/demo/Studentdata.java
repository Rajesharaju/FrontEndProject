package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentdata")
public class Studentdata {

	String name;
	String email;
	@Id
	String regno;
	String branch;
	public Studentdata(String email, String name, String regno, String branch) {
		
		super();
		this.email=email;
		this.name=name;
		this.branch=branch;
		this.regno=regno;
		
	}
	public Studentdata() {
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
}
